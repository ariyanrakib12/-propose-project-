const bgMusic = document.getElementById('bg-music');
let musicStarted = false;
function startMusic() {
  if (!musicStarted) {
    bgMusic.play().catch(e => {});
    musicStarted = true;
  }
}
const buttons = document.querySelectorAll('.btn button');
const clickSound = document.getElementById('click-sound');
buttons.forEach(button => {
  button.addEventListener('click', (e) => {
    startMusic();
    clickSound.currentTime = 0;
    clickSound.play();
    const nextId = e.target.getAttribute('data-next');
    if (!nextId) return;
    document.querySelectorAll('.screen').forEach(screen => screen.classList.remove('active'));
    const nextScreen = document.getElementById(nextId);
    if (nextScreen) nextScreen.classList.add('active');
  });
});
